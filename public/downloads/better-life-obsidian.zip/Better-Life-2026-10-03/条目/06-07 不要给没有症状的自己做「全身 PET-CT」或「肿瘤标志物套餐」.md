---
type: "entry"
entry_id: "6-7"
chapter: 6
evidence: "A"
snapshot: "2026-10-03"
tags: ["指南条目"]
source: "https://github.com/eternity4719/HowToLiveBetter/blob/fcc93eb9a4bdc26e8a4e4c94bdaae0a89265927b/book/06-%E5%8F%8D%E9%9D%A2%E6%B8%85%E5%8D%95.md"
---

# 不要给没有症状的自己做「全身 PET-CT」或「肿瘤标志物套餐」

所属主题：[[主题/06 反面清单|反面清单]] · [[原书/book/06-反面清单|完整章节原文]]

## 原书条目

### 7. 不要给没有症状的自己做「全身 PET-CT」或「肿瘤标志物套餐」
<!-- 成本标签: 钱=0 时间=少 毅力=否 收益=中 口径=死亡率 -->
- 成本：全身 PET-CT 一次约 7000 到 10000 元，还要挨一次电离辐射。肿瘤标志物套餐几百元。真正的成本在后面：查出来一处「异常」，其实是虚惊一场（这叫假阳性），接下来的复查、取组织化验、开刀，钱和罪都在这一段。
- 说人话：没症状的人去查，查出来最多的是虚惊一场。做全身 CT 的人八成多至少查出一处「异常」，将近四成被叫回去复查，可大多数是良性的。女性查卵巢癌标志物，死于卵巢癌的反而略多一点，还有人因为虚惊一场白做了一次手术。
- 收益：美国那个给预防措施打分的机构 USPSTF，对没有症状的女性用 CA-125 和超声筛查卵巢癌给了 D 级，意思是建议不做。依据是 PLCO 试验。因卵巢癌死亡的比例，筛查组 0.34%、常规组 0.29%。RR 1.18（95% CI 0.82–1.71）。查了没有好处。因为查错了（假阳性）而白挨一刀的比例，各试验里是 0.2%–3.25%，这些人里最多 15% 出现严重的手术并发症。另一项研究给 1,192 名没有症状的人做全身 CT 筛查。其中 86% 至少查出一处「异常」，37% 被建议进一步检查。原文说「大多数发现按描述是良性的」。它看起来划算，是因为「一次查全身、早发现早治疗」太符合直觉
- 证据等级：A
- 来源：US Preventive Services Task Force (2018). Screening for Ovarian Cancer: US Preventive Services Task Force Recommendation Statement. JAMA（同一份建议另有 USPSTF 官方页）. <https://doi.org/10.1001/jama.2017.21926>、<https://www.uspreventiveservicestaskforce.org/uspstf/recommendation/ovarian-cancer-screening>；Furtado CD et al. (2005). Whole-body CT screening: spectrum of findings and recommendations in 1192 patients. Radiology. <https://doi.org/10.1148/radiol.2372041741>
- 备注：肿瘤标志物那部分有随机对照试验撑着。全身 CT 和 PET-CT 那部分只有「看做过的人后来怎么样」这类跟踪记录，没有分组对照，证据要弱一档，相当于 B 级。真正有证据的那几项筛查，像结直肠癌、宫颈癌、乳腺癌、高危的人做低剂量胸部 CT，是另一回事，见第 1 节。已经有症状的人，或者已经确诊癌症的人做 PET-CT，那是看病不是筛查，另当别论

## 原书中的关联

- [[主题/01 不要早死|第 1 节：不要早死]]
